package com.in28minutes.database.databasedemo2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DatabaseDemo2ApplicationTests {

    @Test
    void contextLoads() {
    }

}
