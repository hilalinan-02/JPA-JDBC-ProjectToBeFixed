package com.in28minutes.database.databasedemo2.jpa;

import com.in28minutes.database.databasedemo2.entity.Person;
import com.in28minutes.database.databasedemo2.jdbc.PersonJdbcDao;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import java.util.Date;

@SpringBootApplication
public class JPADemoApplication implements CommandLineRunner {

    private Logger logger = LoggerFactory.getLogger(this.getClass());
    @Autowired
    PersonJpaRepository repository;

    public static void main(String[] args) {
        SpringApplication.run(JPADemoApplication.class, args);
    }

    @Override
    public void run(String... args) throws Exception {
       // logger.info("All users -> {}", dao.findAll());
        logger.info("User id 1001 -> {}", repository.findbyID(1001));
      //  logger.info("User name merve -> {}", dao.findbyname("Merve"));
       // logger.info("Deleting 1002", dao.deletebyID(1002));
        logger.info("Inserting -> {}",
                repository.insert(new Person("Tara", "Berlin",
                        new Date())));

        logger.info("Update 1003 -> {}",
                repository.update(new Person(10003,"Peter",
                        "Utrecht", new Date())));
        repository.deleteByID(1002);


    }
}
