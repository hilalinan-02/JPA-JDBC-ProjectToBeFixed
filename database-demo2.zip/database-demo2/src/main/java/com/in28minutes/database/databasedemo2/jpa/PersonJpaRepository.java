package com.in28minutes.database.databasedemo2.jpa;

import com.in28minutes.database.databasedemo2.entity.Person;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.transaction.Transactional;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.stereotype.Repository;

//Repository
@Repository
//Transaction
@Transactional
public class PersonJpaRepository {



    //connect to database
    @PersistenceContext
    EntityManager entityManager;
    public Person findbyID(int id) {
      return entityManager.find(Person.class,id) ;

    }
    public Person update(Person person){
        return entityManager.merge(person);
    }
    public Person insert(Person person){
        return entityManager.merge(person);
    }
    public void deleteByID(int id){
        Person person = findbyID(id);
        findbyID(id);
      entityManager.remove(person);

    }

}
