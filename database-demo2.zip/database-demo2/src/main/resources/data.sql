/*create table person
(
    id integer not null,
    name varchar(255) not null,
    location varchar(255),
    birth_date timestamp,
    primary key (id)
);
  */

INSERT INTO PERSON
(ID,NAME,LOCATION,BIRTH_DATE)
VALUES(1001, 'Hilal' , 'Hatay', CURRENT_DATE);

INSERT INTO PERSON
(ID,NAME,LOCATION,BIRTH_DATE)
VALUES(1002, 'Merve' , 'Hatay', CURRENT_DATE);

INSERT INTO PERSON
(ID,NAME,LOCATION,BIRTH_DATE)
VALUES(1003, 'Büsra' , 'Hatay', CURRENT_DATE);